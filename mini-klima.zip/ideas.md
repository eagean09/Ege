# Mini Klima - Tasarım Fikirleri

## Üç Farklı Yaklaşım

### 1. Endüstriyel Blueprint
**Tema:** Mühendislik çizim estetiği — teknik çizim kağıdı dokusu, grid çizgileri, mavi-beyaz palet
**Giriş:** Bir CAD çizimi gibi hissettiren, mühendislik estetiğini ön plana çıkaran tasarım. Teknik hassasiyeti ve el yapımı bir projenin gururunu yansıtır.
**Olasılık:** 0.07

### 2. Soğuk Nefes — Seçilen Yaklaşım ✓
**Tema:** Buz mavisi ve derin gece renkleri, soğuk hava akışını simüle eden animasyonlar
**Giriş:** Klimanın özünü — soğutma, hava akışı, termal kontrol — görsel bir dile çeviren, sürükleyici ve modern bir deneyim.
**Olasılık:** 0.05

### 3. Maker Atölyesi
**Tema:** Sıcak ahşap doku, sarı vurgu renkleri, el yazısı fontlar — DIY/maker kültürü estetiği
**Giriş:** Bir hobi projesinin sıcaklığını ve el emeğini ön plana çıkaran, organik ve samimi bir tasarım.
**Olasılık:** 0.03

---

## Seçilen Yaklaşım: "Soğuk Nefes"

### Design Movement
Cryo-Industrial Modernism — soğuk teknoloji estetiği ile temiz Bauhaus geometrisinin birleşimi

### Core Principles
1. Soğukluk hissini renk, animasyon ve doku ile somutlaştır
2. Teknik detayları görsel bir anlatıya dönüştür
3. Asimetrik düzenler ve dinamik akış hissi
4. Parçacık ve akış animasyonları ile canlı bir atmosfer

### Color Philosophy
- **Ana Renk:** Buz mavisi `oklch(0.72 0.12 220)` — klimanın soğutucu özünü temsil eder
- **Derin Zemin:** Gece mavisi `oklch(0.12 0.04 240)` — derinlik ve teknolojik ağırlık
- **Vurgu:** Elektrik mavisi `oklch(0.65 0.20 230)` — enerji ve hareket
- **Sıcak Kontrast:** Amber `oklch(0.75 0.15 65)` — Peltier'in sıcak yüzeyini simgeler
- Renk felsefesi: soğuk-sıcak zıtlığı, Peltier efektinin görsel metaforu

### Layout Paradigm
Dikey kaydırma ile tetiklenen bölümler; her bölüm tam ekran. Sol-sağ asimetrik içerik yerleşimi. Scroll-triggered reveal animasyonları. Floating 3D model efekti.

### Signature Elements
1. **Parçacık akışı** — Soğuk hava parçacıklarının yukarı doğru süzüldüğü animasyon
2. **Dönen fan** — Hero bölümünde CSS ile dönen fan animasyonu
3. **Isı gradyanı çizgisi** — Sıcak/soğuk yüzey ayrımını gösteren animasyonlu gradient

### Interaction Philosophy
Scroll ile tetiklenen animasyonlar, hover'da parıltı efektleri, bileşen kartlarında 3D tilt efekti

### Animation
- Fan: `rotate` keyframe, sürekli döngü, 2s linear
- Parçacıklar: `translateY` + `opacity` kombinasyonu, staggered timing
- Bölüm girişleri: `translateY(40px) opacity(0)` → `translateY(0) opacity(1)`, 600ms ease-out
- Isı akışı: gradient animasyonu, 3s ease-in-out loop
- Kart hover: `perspective(1000px) rotateX/Y`, 300ms ease-out

### Typography System
- **Display:** Space Grotesk Bold — geometrik, teknik, modern
- **Body:** Inter Regular — temiz, okunabilir
- **Mono:** JetBrains Mono — teknik değerler ve ölçüler için
- Hiyerarşi: 72px hero → 48px section → 24px card → 16px body

### Brand Essence
"El yapımı mühendislik harikası — cebinize sığan soğutma teknolojisi." Kişilik: **Meraklı, Hassas, Yenilikçi**

### Brand Voice
Başlıklar teknik ama ilham verici: "Peltier Efektiyle Soğutma" değil "Termoelektrik Sihir"
CTA örneği: "Nasıl Çalışır?" / "Tasarımı İncele"

### Wordmark & Logo
Stilize bir kar tanesi + fan pervanesi kombinasyonu; geometrik, tek renk

### Signature Brand Color
Buz mavisi `oklch(0.72 0.12 220)` — Mini Klima'nın kimliği

## Style Decisions
- Tüm bölümler tam ekran yükseklikte
- Parçacık animasyonu canvas tabanlı değil, CSS keyframe ile
- Koyu tema varsayılan
