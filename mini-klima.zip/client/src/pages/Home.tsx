// Soğuk Nefes Teması — Ana Sayfa: tüm bölümleri birleştiren yapı
import Navbar from "@/components/Navbar";
import HeroSection from "@/components/HeroSection";
import HowItWorksSection from "@/components/HowItWorksSection";
import ComponentsSection from "@/components/ComponentsSection";
import TechSpecsSection from "@/components/TechSpecsSection";
import ModelSection from "@/components/ModelSection";
import Footer from "@/components/Footer";
import ColdBreathDivider from "@/components/ColdBreathDivider";

export default function Home() {
  return (
    <div
      className="min-h-screen"
      style={{ background: "oklch(0.09 0.03 245)" }}
    >
      <Navbar />
      <HeroSection />
      <ColdBreathDivider />
      <HowItWorksSection />
      <ColdBreathDivider reverse />
      <ComponentsSection />
      <ColdBreathDivider />
      <TechSpecsSection />
      <ColdBreathDivider reverse />
      <ModelSection />
      <Footer />
    </div>
  );
}
