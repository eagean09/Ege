// Soğuk Nefes Teması — Hero: tam ekran, parçacık efekti, dönen fan, soğuk hava animasyonu
import { useEffect, useState } from "react";
import ParticleField from "./ParticleField";
import FanSVG from "./FanSVG";

const klimaImgUrl = "/manus-storage/klima_3d_13231f3c.png";
const heroBgUrl = "/manus-storage/hero_bg_6ae38424.jpg";

export default function HeroSection() {
  const [loaded, setLoaded] = useState(false);
  const [temp, setTemp] = useState(28);

  useEffect(() => {
    const timer = setTimeout(() => setLoaded(true), 200);
    return () => clearTimeout(timer);
  }, []);

  // Simüle sıcaklık düşüşü animasyonu
  useEffect(() => {
    if (!loaded) return;
    const interval = setInterval(() => {
      setTemp((prev) => {
        if (prev <= 18) return 28;
        return prev - 1;
      });
    }, 300);
    return () => clearInterval(interval);
  }, [loaded]);

  return (
    <section
      id="proje"
      className="relative min-h-screen flex items-center overflow-hidden"
      style={{
        background: `radial-gradient(ellipse at 60% 50%, oklch(0.18 0.08 235 / 0.4) 0%, oklch(0.09 0.03 245) 70%)`,
      }}
    >
      {/* Background image */}
      <div
        className="absolute inset-0"
        style={{
          backgroundImage: `url(${heroBgUrl})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
          opacity: 0.15,
        }}
      />

      {/* Particle field */}
      <ParticleField count={50} />

      {/* Grid overlay */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(oklch(0.65 0.20 230 / 0.04) 1px, transparent 1px),
            linear-gradient(90deg, oklch(0.65 0.20 230 / 0.04) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      {/* Radial glow */}
      <div
        className="absolute pointer-events-none"
        style={{
          width: "600px",
          height: "600px",
          borderRadius: "50%",
          background: "radial-gradient(circle, oklch(0.65 0.20 230 / 0.12) 0%, transparent 70%)",
          right: "10%",
          top: "50%",
          transform: "translateY(-50%)",
        }}
      />

      <div className="container relative z-10">
        <div className="grid lg:grid-cols-2 gap-12 items-center min-h-screen py-24">
          {/* Left: Text content */}
          <div className="flex flex-col gap-6">
            {/* Badge */}
            <div
              className="inline-flex items-center gap-2 w-fit px-3 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase"
              style={{
                background: "oklch(0.65 0.20 230 / 0.12)",
                border: "1px solid oklch(0.65 0.20 230 / 0.3)",
                color: "oklch(0.72 0.12 220)",
                opacity: loaded ? 1 : 0,
                transform: loaded ? "translateY(0)" : "translateY(20px)",
                transition: "all 0.6s cubic-bezier(0.23, 1, 0.32, 1) 0.1s",
              }}
            >
              <span
                className="w-1.5 h-1.5 rounded-full animate-frost"
                style={{ background: "oklch(0.72 0.12 220)" }}
              />
              Peltier Thermoelectric Cooling
            </div>

            {/* Heading */}
            <div
              style={{
                opacity: loaded ? 1 : 0,
                transform: loaded ? "translateY(0)" : "translateY(30px)",
                transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1) 0.2s",
              }}
            >
              <h1
                className="font-bold leading-tight"
                style={{
                  fontFamily: "'Space Grotesk', sans-serif",
                  fontSize: "clamp(2.5rem, 5vw, 4.5rem)",
                  color: "oklch(0.92 0.04 215)",
                  lineHeight: 1.1,
                }}
              >
                Mini
                <br />
                <span
                  style={{
                    background: "linear-gradient(135deg, oklch(0.72 0.12 220), oklch(0.65 0.20 230))",
                    WebkitBackgroundClip: "text",
                    WebkitTextFillColor: "transparent",
                    backgroundClip: "text",
                  }}
                >
                  Cool
                </span>
                <br />
                <span style={{ fontSize: "0.6em", color: "oklch(0.55 0.05 225)" }}>
                  Project
                </span>
              </h1>
            </div>

            {/* Description */}
            <p
              className="text-base leading-relaxed max-w-md"
              style={{
                color: "oklch(0.65 0.05 225)",
                opacity: loaded ? 1 : 0,
                transform: loaded ? "translateY(0)" : "translateY(20px)",
                transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1) 0.35s",
              }}
            >
              A compact thermoelectric cooling device designed with a Peltier module,
              aluminum cooling block, and 24V fan. An engineering marvel for personal
              desktop cooling experience.
            </p>

            {/* Live temperature display */}
            <div
              className="flex items-center gap-4"
              style={{
                opacity: loaded ? 1 : 0,
                transform: loaded ? "translateY(0)" : "translateY(20px)",
                transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1) 0.45s",
              }}
            >
              <div
                className="flex flex-col gap-1 px-4 py-3 rounded-xl"
                style={{
                  background: "oklch(0.65 0.20 230 / 0.08)",
                  border: "1px solid oklch(0.65 0.20 230 / 0.2)",
                }}
              >
                <span
                  className="text-xs font-mono uppercase tracking-wider"
                  style={{ color: "oklch(0.55 0.05 225)" }}
                >
                  Temperature
                </span>
                <span
                  className="text-2xl font-bold font-mono"
                  style={{ color: temp <= 20 ? "oklch(0.72 0.12 220)" : "oklch(0.75 0.15 65)" }}
                >
                  {temp}°C
                </span>
              </div>
              <div
                className="flex flex-col gap-1 px-4 py-3 rounded-xl"
                style={{
                  background: "oklch(0.65 0.20 230 / 0.08)",
                  border: "1px solid oklch(0.65 0.20 230 / 0.2)",
                }}
              >
                <span
                  className="text-xs font-mono uppercase tracking-wider"
                  style={{ color: "oklch(0.55 0.05 225)" }}
                >
                  Power
                </span>
                <span className="text-2xl font-bold font-mono" style={{ color: "oklch(0.72 0.12 220)" }}>
                  24V
                </span>
              </div>
              <div
                className="flex flex-col gap-1 px-4 py-3 rounded-xl"
                style={{
                  background: "oklch(0.65 0.20 230 / 0.08)",
                  border: "1px solid oklch(0.65 0.20 230 / 0.2)",
                }}
              >
                <span
                  className="text-xs font-mono uppercase tracking-wider"
                  style={{ color: "oklch(0.55 0.05 225)" }}
                >
                  Fan Size
                </span>
                <span className="text-2xl font-bold font-mono" style={{ color: "oklch(0.72 0.12 220)" }}>
                  60mm
                </span>
              </div>
            </div>

            {/* CTA buttons */}
            <div
              className="flex flex-wrap gap-3 mt-2"
              style={{
                opacity: loaded ? 1 : 0,
                transform: loaded ? "translateY(0)" : "translateY(20px)",
                transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1) 0.55s",
              }}
            >
              <a
                href="#calisma"
                className="px-6 py-3 rounded-full font-semibold text-sm transition-all duration-200 active:scale-95"
                style={{
                  background: "linear-gradient(135deg, oklch(0.65 0.20 230), oklch(0.55 0.18 240))",
                  color: "oklch(0.98 0.01 220)",
                  boxShadow: "0 0 20px oklch(0.65 0.20 230 / 0.4)",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.boxShadow = "0 0 30px oklch(0.65 0.20 230 / 0.6)";
                  e.currentTarget.style.transform = "translateY(-1px)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.boxShadow = "0 0 20px oklch(0.65 0.20 230 / 0.4)";
                  e.currentTarget.style.transform = "translateY(0)";
                }}
              >
                How It Works
              </a>
              <a
                href="https://cad.onshape.com/documents/21fe0276ffc8c6ed3b8018b1/w/d76675b1995a050e7ea5c5d8/e/3160da51f33fcb1a54985a75"
                target="_blank"
                rel="noopener noreferrer"
                className="px-6 py-3 rounded-full font-semibold text-sm transition-all duration-200 active:scale-95"
                style={{
                  background: "transparent",
                  border: "1px solid oklch(0.65 0.20 230 / 0.4)",
                  color: "oklch(0.72 0.12 220)",
                }}
                onMouseEnter={(e) => {
                  e.currentTarget.style.background = "oklch(0.65 0.20 230 / 0.1)";
                  e.currentTarget.style.borderColor = "oklch(0.65 0.20 230 / 0.7)";
                }}
                onMouseLeave={(e) => {
                  e.currentTarget.style.background = "transparent";
                  e.currentTarget.style.borderColor = "oklch(0.65 0.20 230 / 0.4)";
                }}
              >
                View 3D Model ↗
              </a>
            </div>
          </div>

          {/* Right: 3D Model + Fan animation */}
          <div
            className="relative flex items-center justify-center"
            style={{
              opacity: loaded ? 1 : 0,
              transform: loaded ? "translateY(0)" : "translateY(40px)",
              transition: "all 0.9s cubic-bezier(0.23, 1, 0.32, 1) 0.3s",
            }}
          >
            {/* Glow ring behind model */}
            <div
              className="absolute rounded-full animate-frost"
              style={{
                width: "380px",
                height: "380px",
                background: "radial-gradient(circle, oklch(0.65 0.20 230 / 0.15) 0%, transparent 70%)",
              }}
            />

            {/* Rotating outer ring */}
            <div
              className="absolute animate-spin-slow"
              style={{ width: "360px", height: "360px" }}
            >
              <svg viewBox="0 0 360 360" className="w-full h-full">
                <circle
                  cx="180"
                  cy="180"
                  r="170"
                  fill="none"
                  stroke="oklch(0.65 0.20 230 / 0.15)"
                  strokeWidth="1"
                  strokeDasharray="8 16"
                />
              </svg>
            </div>

            {/* Klima model image */}
            <div className="relative animate-float z-10">
              <img
                src={klimaImgUrl}
                alt="Mini Cool 3D Model"
                className="w-72 h-auto object-contain"
                style={{
                  filter: "drop-shadow(0 20px 40px oklch(0.65 0.20 230 / 0.4)) drop-shadow(0 0 60px oklch(0.72 0.12 220 / 0.2))",
                }}
              />

              {/* Fan overlay at top */}
              <div
                className="absolute"
                style={{ top: "-10px", left: "50%", transform: "translateX(-50%)" }}
              >
                <FanSVG size={72} speed="fast" />
              </div>
            </div>

            {/* Thermal annotation lines */}
            <svg
              className="absolute inset-0 w-full h-full pointer-events-none z-20"
              viewBox="0 0 400 500"
              style={{ opacity: 0.5 }}
            >
              {/* Cold side annotation */}
              <line x1="280" y1="380" x2="340" y2="420" stroke="oklch(0.72 0.12 220 / 0.4)" strokeWidth="1" />
              <circle cx="340" cy="420" r="2" fill="oklch(0.72 0.12 220 / 0.6)" />
              {/* Hot side annotation */}
              <line x1="280" y1="440" x2="340" y2="460" stroke="oklch(0.75 0.15 65 / 0.4)" strokeWidth="1" />
              <circle cx="340" cy="460" r="2" fill="oklch(0.75 0.15 65 / 0.6)" />
              {/* Fan annotation */}
              <line x1="200" y1="60" x2="140" y2="30" stroke="oklch(0.65 0.20 230 / 0.4)" strokeWidth="1" />
              <circle cx="140" cy="30" r="2" fill="oklch(0.65 0.20 230 / 0.6)" />
            </svg>

            {/* Floating spec tags */}
            <div
              className="absolute top-8 right-0 px-3 py-2 rounded-lg text-xs font-mono animate-fade-up"
              style={{
                background: "oklch(0.13 0.04 240 / 0.9)",
                border: "1px solid oklch(0.65 0.20 230 / 0.3)",
                color: "oklch(0.72 0.12 220)",
                animationDelay: "1s",
                opacity: 0,
                animationFillMode: "forwards",
              }}
            >
              60×60×25mm Fan
            </div>
            <div
              className="absolute bottom-16 left-0 px-3 py-2 rounded-lg text-xs font-mono animate-fade-up"
              style={{
                background: "oklch(0.13 0.04 240 / 0.9)",
                border: "1px solid oklch(0.75 0.15 65 / 0.4)",
                color: "oklch(0.75 0.15 65)",
                animationDelay: "1.3s",
                opacity: 0,
                animationFillMode: "forwards",
              }}
            >
              Peltier Module
            </div>
            <div
              className="absolute bottom-4 right-4 px-3 py-2 rounded-lg text-xs font-mono animate-fade-up"
              style={{
                background: "oklch(0.13 0.04 240 / 0.9)",
                border: "1px solid oklch(0.65 0.20 230 / 0.3)",
                color: "oklch(0.72 0.12 220)",
                animationDelay: "1.6s",
                opacity: 0,
                animationFillMode: "forwards",
              }}
            >
              Al. Block 60×60mm
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        style={{
          opacity: loaded ? 0.6 : 0,
          transition: "opacity 1s ease 1.5s",
        }}
      >
        <span className="text-xs font-mono tracking-widest uppercase" style={{ color: "oklch(0.55 0.05 225)" }}>
          Explore
        </span>
        <div
          className="w-px h-12 relative overflow-hidden"
          style={{ background: "oklch(0.65 0.20 230 / 0.2)" }}
        >
          <div
            className="absolute top-0 left-0 w-full"
            style={{
              height: "40%",
              background: "oklch(0.65 0.20 230)",
              animation: "heat-cold-flow 1.5s ease-in-out infinite",
            }}
          />
        </div>
      </div>
    </section>
  );
}
