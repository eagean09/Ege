// Soğuk Nefes Teması — 3D Model bölümü: OnShape embed + CTA
import { useEffect, useRef, useState } from "react";
import FanSVG from "./FanSVG";

const klimaImgUrl = "/manus-storage/klima_3d_13231f3c.png";

export default function ModelSection() {
  const [visible, setVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const views = [
    { label: "Ön Görünüm", icon: "◻" },
    { label: "Yan Görünüm", icon: "◼" },
    { label: "Üst Görünüm", icon: "⬛" },
    { label: "İzometrik", icon: "◈" },
  ];

  return (
    <section
      id="model"
      ref={sectionRef}
      className="relative py-24 overflow-hidden"
      style={{ background: "oklch(0.11 0.04 242)" }}
    >
      {/* Decorative glow */}
      <div
        className="absolute pointer-events-none"
        style={{
          width: "500px",
          height: "500px",
          borderRadius: "50%",
          background: "radial-gradient(circle, oklch(0.65 0.20 230 / 0.08) 0%, transparent 70%)",
          left: "-100px",
          bottom: "-100px",
        }}
      />

      <div className="container relative z-10">
        {/* Header */}
        <div
          className="mb-12"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1)",
          }}
        >
          <div
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase mb-4"
            style={{
              background: "oklch(0.65 0.20 230 / 0.1)",
              border: "1px solid oklch(0.65 0.20 230 / 0.25)",
              color: "oklch(0.65 0.20 230)",
            }}
          >
            CAD Design
          </div>
          <h2
            className="font-bold"
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2rem, 4vw, 3rem)",
              color: "oklch(0.92 0.04 215)",
            }}
          >
            Inside the Design
          </h2>
          <p className="mt-3 max-w-xl" style={{ color: "oklch(0.60 0.05 225)" }}>
            Seven parts brought to life in OnShape, assembled with 5 fastened mates. Every millimeter calculated, every angle optimized for thermal flow.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left: Model showcase */}
          <div
            className="relative"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateX(0)" : "translateX(-40px)",
              transition: "all 0.8s cubic-bezier(0.23, 1, 0.32, 1) 0.2s",
            }}
          >
            <div
              className="relative rounded-3xl overflow-hidden"
              style={{
                background: "oklch(0.09 0.03 245)",
                border: "1px solid oklch(1 0 0 / 8%)",
                minHeight: "400px",
              }}
            >
              {/* Grid background */}
              <div
                className="absolute inset-0"
                style={{
                  backgroundImage: `
                    linear-gradient(oklch(0.65 0.20 230 / 0.05) 1px, transparent 1px),
                    linear-gradient(90deg, oklch(0.65 0.20 230 / 0.05) 1px, transparent 1px)
                  `,
                  backgroundSize: "40px 40px",
                }}
              />

              {/* Model image */}
              <div className="relative z-10 flex items-center justify-center p-12">
                <div className="relative animate-float">
                  <img
                    src={klimaImgUrl}
                    alt="Mini Klima 3D Model"
                    className="w-64 h-auto object-contain"
                    style={{
                      filter: "drop-shadow(0 20px 40px oklch(0.65 0.20 230 / 0.5))",
                    }}
                  />
                  {/* Fan animation overlay */}
                  <div
                    className="absolute"
                    style={{ top: "-5px", left: "50%", transform: "translateX(-50%)" }}
                  >
                    <FanSVG size={60} speed="medium" />
                  </div>
                </div>
              </div>

              {/* View labels */}
              <div className="absolute bottom-4 left-4 flex gap-2 flex-wrap">
                {views.map((v) => (
                  <span
                    key={v.label}
                    className="px-2 py-1 rounded text-xs font-mono"
                    style={{
                      background: "oklch(0.65 0.20 230 / 0.1)",
                      color: "oklch(0.65 0.20 230)",
                      border: "1px solid oklch(0.65 0.20 230 / 0.2)",
                    }}
                  >
                    {v.icon} {v.label}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Right: Assembly info + CTA */}
          <div
            className="flex flex-col gap-6"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateX(0)" : "translateX(40px)",
              transition: "all 0.8s cubic-bezier(0.23, 1, 0.32, 1) 0.3s",
            }}
          >
            {/* Assembly tree */}
            <div
              className="rounded-2xl p-5"
              style={{
                background: "oklch(0.13 0.04 240)",
                border: "1px solid oklch(1 0 0 / 8%)",
              }}
            >
              <h3
                className="font-semibold mb-4 text-sm"
                style={{ fontFamily: "'Space Grotesk', sans-serif", color: "oklch(0.75 0.04 220)" }}
              >
                Assembly Ağacı
              </h3>
              <div className="flex flex-col gap-2 font-mono text-sm">
                {[
                  { name: "Klima (Ana Montaj)", depth: 0, color: "oklch(0.72 0.12 220)" },
                  { name: "fan <1>", depth: 1, color: "oklch(0.65 0.20 230)" },
                  { name: "Peltier(C)", depth: 1, color: "oklch(0.65 0.20 230)" },
                  { name: "Alüminyum Blok(60x60mm)", depth: 1, color: "oklch(0.65 0.20 230)" },
                  { name: "Klima Dış Cephe", depth: 1, color: "oklch(0.65 0.20 230)" },
                  { name: "Peltier Tutucu", depth: 1, color: "oklch(0.65 0.20 230)" },
                  { name: "Mate features (5×)", depth: 1, color: "oklch(0.75 0.15 65)" },
                ].map((item) => (
                  <div
                    key={item.name}
                    className="flex items-center gap-2"
                    style={{ paddingLeft: `${item.depth * 16}px` }}
                  >
                    <span style={{ color: "oklch(0.40 0.05 230)" }}>
                      {item.depth > 0 ? "└─" : "📁"}
                    </span>
                    <span style={{ color: item.color }}>{item.name}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Stats row */}
            <div className="grid grid-cols-3 gap-3">
              {[
                { label: "Bileşen", value: "7" },
                { label: "Montaj", value: "5×" },
                { label: "Tasarım", value: "CAD" },
              ].map((s) => (
                <div
                  key={s.label}
                  className="rounded-xl p-4 text-center"
                  style={{
                    background: "oklch(0.13 0.04 240)",
                    border: "1px solid oklch(1 0 0 / 8%)",
                  }}
                >
                  <div
                    className="text-2xl font-bold font-mono"
                    style={{ color: "oklch(0.72 0.12 220)" }}
                  >
                    {s.value}
                  </div>
                  <div className="text-xs mt-1" style={{ color: "oklch(0.55 0.05 225)" }}>
                    {s.label}
                  </div>
                </div>
              ))}
            </div>

            {/* CTA */}
            <a
              href="https://cad.onshape.com/documents/21fe0276ffc8c6ed3b8018b1/w/d76675b1995a050e7ea5c5d8/e/3160da51f33fcb1a54985a75"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center justify-center gap-3 px-6 py-4 rounded-2xl font-semibold text-sm transition-all duration-200 active:scale-98"
              style={{
                background: "linear-gradient(135deg, oklch(0.65 0.20 230 / 0.15), oklch(0.72 0.12 220 / 0.1))",
                border: "1px solid oklch(0.65 0.20 230 / 0.4)",
                color: "oklch(0.92 0.04 215)",
              }}
              onMouseEnter={(e) => {
                e.currentTarget.style.background = "linear-gradient(135deg, oklch(0.65 0.20 230 / 0.25), oklch(0.72 0.12 220 / 0.2))";
                e.currentTarget.style.borderColor = "oklch(0.65 0.20 230 / 0.7)";
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow = "0 8px 24px oklch(0.65 0.20 230 / 0.2)";
              }}
              onMouseLeave={(e) => {
                e.currentTarget.style.background = "linear-gradient(135deg, oklch(0.65 0.20 230 / 0.15), oklch(0.72 0.12 220 / 0.1))";
                e.currentTarget.style.borderColor = "oklch(0.65 0.20 230 / 0.4)";
                e.currentTarget.style.transform = "translateY(0)";
                e.currentTarget.style.boxShadow = "none";
              }}
            >
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M18 13v6a2 2 0 01-2 2H5a2 2 0 01-2-2V8a2 2 0 012-2h6" />
                <polyline points="15 3 21 3 21 9" />
                <line x1="10" y1="14" x2="21" y2="3" />
              </svg>
              OnShape'de 3D Modeli Aç
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
