// Soğuk Nefes Teması — Navbar: cam efektli, scroll'da opaklık kazanan
import { useState, useEffect } from "react";
const logoUrl = "https://3000-ir6303a50hvqgzb51ydh4-4ee4a2b5.sg1.manus.computer/manus-storage/logo_icon_bded498f.png";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  const navLinks = [
    { label: "Project", href: "#proje" },
    { label: "How It Works", href: "#calisma" },
    { label: "Components", href: "#bilesenleri" },
    { label: "Specs", href: "#teknik" },
    { label: "3D Model", href: "#model" },
  ];

  return (
    <nav
      className="fixed top-0 left-0 right-0 z-50 transition-all duration-300"
      style={{
        background: scrolled
          ? "oklch(0.09 0.03 245 / 0.92)"
          : "transparent",
        backdropFilter: scrolled ? "blur(16px)" : "none",
        borderBottom: scrolled ? "1px solid oklch(1 0 0 / 8%)" : "none",
      }}
    >
      <div className="container flex items-center justify-between h-16">
        <a href="#" className="flex items-center gap-2.5 group">
          <img
            src={logoUrl}
            alt="Mini Klima Logo"
            className="w-8 h-8 transition-transform duration-300 group-hover:rotate-45"
          />
          <span
            className="font-bold text-lg tracking-tight"
            style={{ fontFamily: "'Space Grotesk', sans-serif", color: "oklch(0.92 0.04 215)" }}
          >
            Mini<span style={{ color: "oklch(0.65 0.20 230)" }}>Cool</span>
          </span>
        </a>

        {/* Desktop nav */}
        <div className="hidden md:flex items-center gap-6">
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="text-sm font-medium transition-colors duration-200"
              style={{ color: "oklch(0.65 0.05 225)" }}
              onMouseEnter={(e) => (e.currentTarget.style.color = "oklch(0.72 0.12 220)")}
              onMouseLeave={(e) => (e.currentTarget.style.color = "oklch(0.65 0.05 225)")}
            >
              {link.label}
            </a>
          ))}
          <a
            href="https://cad.onshape.com/documents/21fe0276ffc8c6ed3b8018b1/w/d76675b1995a050e7ea5c5d8/e/3160da51f33fcb1a54985a75"
            target="_blank"
            rel="noopener noreferrer"
            className="px-4 py-1.5 rounded-full text-sm font-semibold transition-all duration-200"
            style={{
              background: "oklch(0.65 0.20 230 / 0.15)",
              border: "1px solid oklch(0.65 0.20 230 / 0.4)",
              color: "oklch(0.72 0.12 220)",
            }}
            onMouseEnter={(e) => {
              e.currentTarget.style.background = "oklch(0.65 0.20 230 / 0.3)";
              e.currentTarget.style.borderColor = "oklch(0.65 0.20 230 / 0.7)";
            }}
            onMouseLeave={(e) => {
              e.currentTarget.style.background = "oklch(0.65 0.20 230 / 0.15)";
              e.currentTarget.style.borderColor = "oklch(0.65 0.20 230 / 0.4)";
            }}
          >
            View CAD →
          </a>
        </div>

        {/* Mobile menu button */}
        <button
          className="md:hidden flex flex-col gap-1.5 p-2"
          onClick={() => setMenuOpen(!menuOpen)}
          aria-label="Menu"
        >
          <span
            className="block w-5 h-0.5 transition-all duration-300"
            style={{
              background: "oklch(0.72 0.12 220)",
              transform: menuOpen ? "rotate(45deg) translateY(8px)" : "none",
            }}
          />
          <span
            className="block w-5 h-0.5 transition-all duration-300"
            style={{
              background: "oklch(0.72 0.12 220)",
              opacity: menuOpen ? 0 : 1,
            }}
          />
          <span
            className="block w-5 h-0.5 transition-all duration-300"
            style={{
              background: "oklch(0.72 0.12 220)",
              transform: menuOpen ? "rotate(-45deg) translateY(-8px)" : "none",
            }}
          />
        </button>
      </div>

      {/* Mobile menu */}
      {menuOpen && (
        <div
          className="md:hidden px-4 pb-4 flex flex-col gap-3"
          style={{ background: "oklch(0.09 0.03 245 / 0.97)" }}
        >
          {navLinks.map((link) => (
            <a
              key={link.href}
              href={link.href}
              onClick={() => setMenuOpen(false)}
              className="text-sm font-medium py-2 border-b"
              style={{
                color: "oklch(0.72 0.12 220)",
                borderColor: "oklch(1 0 0 / 8%)",
              }}
            >
              {link.label}
            </a>
          ))}
        </div>
      )}
    </nav>
  );
}
