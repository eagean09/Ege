// Soğuk Nefes Teması — Bileşenler: tilt efektli kartlar, hover animasyonları
import { useRef, useEffect, useState } from "react";

const fanImgUrl = "/manus-storage/fan_closeup_8c5f180e.jpg";
const peltierImgUrl = "/manus-storage/peltier_module_7bc01a12.jpg";

const components = [
  {
    id: "fan",
    name: "24V 60×60×25mm Fan",
    category: "Soğutma",
    description:
      "Yüksek debili aksiyel fan, alüminyum blok üzerinden soğuk havayı hızla dışarı atar. 24V DC ile çalışır, düşük gürültü seviyesinde yüksek performans sunar.",
    specs: [
      { label: "Boyut", value: "60×60×25mm" },
      { label: "Voltaj", value: "24V DC" },
      { label: "Tip", value: "Aksiyel" },
      { label: "Kanat", value: "7 adet" },
    ],
    image: fanImgUrl,
    accentColor: "oklch(0.72 0.12 220)",
    icon: "💨",
  },
  {
    id: "peltier",
    name: "Peltier Modülü",
    category: "Termoelektrik",
    description:
      "TEC (Thermoelectric Cooler) modülü, elektrik akımını ısı transferine dönüştürür. Bir yüzey soğurken diğer yüzey ısınır — mekanik parça olmadan soğutma.",
    specs: [
      { label: "Tip", value: "TEC1-12706" },
      { label: "Boyut", value: "40×40mm" },
      { label: "Güç", value: "~60W" },
      { label: "ΔT maks", value: "~68°C" },
    ],
    image: peltierImgUrl,
    accentColor: "oklch(0.65 0.20 230)",
    icon: "⚡",
  },
  {
    id: "alblock",
    name: "Alüminyum Blok",
    category: "Isı Transferi",
    description:
      "60×60mm alüminyum blok, Peltier modülünün soğuk yüzeyinden gelen soğukluğu hava kanalına aktarır. Yüksek termal iletkenlik değeri ile maksimum verim sağlar.",
    specs: [
      { label: "Boyut", value: "60×60mm" },
      { label: "Malzeme", value: "Al 6061" },
      { label: "İletkenlik", value: "167 W/m·K" },
      { label: "Yüzey", value: "İşlenmiş" },
    ],
    image: null,
    accentColor: "oklch(0.75 0.15 65)",
    icon: "🧊",
  },
  {
    id: "cephe",
    name: "Dış Cephe Kasası",
    category: "Yapı",
    description:
      "3D yazıcı ile üretilen kompakt dış kasa, tüm bileşenleri bir arada tutar. Hava giriş/çıkış delikleri ve fan montaj yuvası ile optimize edilmiş tasarım.",
    specs: [
      { label: "Üretim", value: "3D Baskı" },
      { label: "Malzeme", value: "PLA/PETG" },
      { label: "Delikler", value: "Yuvarlak ızgara" },
      { label: "Montaj", value: "Fastened" },
    ],
    image: null,
    accentColor: "oklch(0.72 0.12 220)",
    icon: "📦",
  },
];

function ComponentCard({ comp, index, visible }: { comp: typeof components[0]; index: number; visible: boolean }) {
  const cardRef = useRef<HTMLDivElement>(null);
  const [tilt, setTilt] = useState({ x: 0, y: 0 });
  const [hovered, setHovered] = useState(false);

  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const rect = cardRef.current?.getBoundingClientRect();
    if (!rect) return;
    const x = ((e.clientX - rect.left) / rect.width - 0.5) * 10;
    const y = -((e.clientY - rect.top) / rect.height - 0.5) * 10;
    setTilt({ x, y });
  };

  return (
    <div
      ref={cardRef}
      onMouseMove={handleMouseMove}
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => { setTilt({ x: 0, y: 0 }); setHovered(false); }}
      className="rounded-2xl overflow-hidden transition-all duration-300 cursor-pointer"
      style={{
        background: "oklch(0.13 0.04 240)",
        border: `1px solid ${hovered ? comp.accentColor.replace(")", " / 0.4)") : "oklch(1 0 0 / 8%)"}`,
        borderColor: hovered
          ? comp.accentColor.replace("oklch(", "oklch(").replace(")", " / 0.4)")
          : "oklch(1 0 0 / 8%)",
        transform: `perspective(1000px) rotateX(${tilt.y}deg) rotateY(${tilt.x}deg) ${hovered ? "scale(1.02)" : "scale(1)"}`,
        boxShadow: hovered ? `0 20px 40px ${comp.accentColor.replace(")", " / 0.15)")}` : "none",
        opacity: visible ? 1 : 0,
        transitionDelay: `${index * 0.1 + 0.2}s`,
        transitionProperty: "opacity, transform, box-shadow, border-color",
        transitionDuration: hovered ? "0.15s, 0.3s, 0.3s, 0.3s" : "0.3s",
      }}
    >
      {/* Image or icon area */}
      <div
        className="relative h-40 flex items-center justify-center overflow-hidden"
        style={{
          background: comp.image
            ? "oklch(0.10 0.035 242)"
            : `linear-gradient(135deg, ${comp.accentColor.replace(")", " / 0.08)")} 0%, oklch(0.11 0.04 242) 100%)`,
        }}
      >
        {comp.image ? (
          <img
            src={comp.image}
            alt={comp.name}
            className="w-full h-full object-cover transition-transform duration-500"
            style={{ transform: hovered ? "scale(1.08)" : "scale(1)" }}
          />
        ) : (
          <span className="text-6xl" style={{ filter: "drop-shadow(0 0 20px currentColor)" }}>
            {comp.icon}
          </span>
        )}
        <div
          className="absolute inset-0"
          style={{
            background: `linear-gradient(to bottom, transparent 50%, oklch(0.13 0.04 240))`,
          }}
        />
        <div
          className="absolute top-3 left-3 px-2 py-1 rounded-md text-xs font-semibold"
          style={{
            background: comp.accentColor.replace(")", " / 0.15)"),
            color: comp.accentColor,
            border: `1px solid ${comp.accentColor.replace(")", " / 0.3)")}`,
          }}
        >
          {comp.category}
        </div>
      </div>

      {/* Content */}
      <div className="p-5">
        <h3
          className="font-bold text-base mb-2"
          style={{ fontFamily: "'Space Grotesk', sans-serif", color: "oklch(0.92 0.04 215)" }}
        >
          {comp.name}
        </h3>
        <p className="text-sm leading-relaxed mb-4" style={{ color: "oklch(0.60 0.05 225)" }}>
          {comp.description}
        </p>

        {/* Specs grid */}
        <div className="grid grid-cols-2 gap-2">
          {comp.specs.map((spec) => (
            <div
              key={spec.label}
              className="rounded-lg px-3 py-2"
              style={{ background: "oklch(0.10 0.03 244)" }}
            >
              <div className="text-xs" style={{ color: "oklch(0.50 0.05 225)" }}>
                {spec.label}
              </div>
              <div
                className="text-sm font-semibold font-mono mt-0.5"
                style={{ color: comp.accentColor }}
              >
                {spec.value}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

export default function ComponentsSection() {
  const [visible, setVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.1 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  return (
    <section
      id="bilesenleri"
      ref={sectionRef}
      className="relative py-24 overflow-hidden"
      style={{ background: "oklch(0.11 0.04 242)" }}
    >
      <div className="container relative z-10">
        {/* Header */}
        <div
          className="mb-12"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1)",
          }}
        >
          <div
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase mb-4"
            style={{
              background: "oklch(0.65 0.20 230 / 0.1)",
              border: "1px solid oklch(0.65 0.20 230 / 0.25)",
              color: "oklch(0.65 0.20 230)",
            }}
          >
            Hardware
          </div>
          <h2
            className="font-bold"
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2rem, 4vw, 3rem)",
              color: "oklch(0.92 0.04 215)",
            }}
          >
            Anatomy of Cooling
          </h2>
          <p className="mt-3 max-w-xl" style={{ color: "oklch(0.60 0.05 225)" }}>
            Four components, one mission: cool the air. Each part knows exactly its role in the thermal equation.
          </p>
        </div>

        {/* Cards grid */}
        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {components.map((comp, i) => (
            <ComponentCard key={comp.id} comp={comp} index={i} visible={visible} />
          ))}
        </div>
      </div>
    </section>
  );
}
