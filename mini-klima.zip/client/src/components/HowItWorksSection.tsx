// Soğuk Nefes Teması — Nasıl Çalışır: Peltier efekti adım adım animasyonlu anlatım
import { useState, useEffect, useRef } from "react";

const steps = [
  {
    id: 1,
    title: "Elektrik Akımı",
    subtitle: "Güç Girişi",
    description:
      "24V DC güç kaynağından gelen elektrik akımı Peltier modülüne iletilir. Akım yönü soğutma ve ısıtma yüzeylerini belirler.",
    icon: "⚡",
    color: "oklch(0.75 0.15 65)",
    detail: "24V / ~60W",
  },
  {
    id: 2,
    title: "Peltier Efekti",
    subtitle: "Termoelektrik Dönüşüm",
    description:
      "Seebeck-Peltier prensibiyle çalışan modül, bir yüzeyini soğuturken diğer yüzeyini ısıtır. İki seramik plaka arasında ısı transferi gerçekleşir.",
    icon: "🔵",
    color: "oklch(0.65 0.20 230)",
    detail: "ΔT ≈ 10°C",
  },
  {
    id: 3,
    title: "Isı Transferi",
    subtitle: "Alüminyum Blok",
    description:
      "60×60mm alüminyum blok, Peltier'in soğuk yüzeyinden gelen soğukluğu hava kanalına iletir. Yüksek termal iletkenlik ile verimli transfer sağlar.",
    icon: "🧊",
    color: "oklch(0.72 0.12 220)",
    detail: "Al 6061 — 167 W/m·K",
  },
  {
    id: 4,
    title: "Hava Sirkülasyonu",
    subtitle: "60mm Fan",
    description:
      "24V 60×60×25mm fan, soğutulan alüminyum blok üzerinden havayı çekerek soğuk hava akışı oluşturur. Yuvarlak deliklerden soğuk hava üflenir.",
    icon: "💨",
    color: "oklch(0.72 0.12 220)",
    detail: "60×60×25mm / 24V",
  },
];

export default function HowItWorksSection() {
  const [activeStep, setActiveStep] = useState(0);
  const [visible, setVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) setVisible(true);
      },
      { threshold: 0.2 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!visible) return;
    const interval = setInterval(() => {
      setActiveStep((prev) => (prev + 1) % steps.length);
    }, 2500);
    return () => clearInterval(interval);
  }, [visible]);

  return (
    <section
      id="calisma"
      ref={sectionRef}
      className="relative py-24 overflow-hidden"
      style={{ background: "oklch(0.09 0.03 245)" }}
    >
      {/* Background decoration */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(oklch(0.65 0.20 230 / 0.03) 1px, transparent 1px),
            linear-gradient(90deg, oklch(0.65 0.20 230 / 0.03) 1px, transparent 1px)
          `,
          backgroundSize: "80px 80px",
        }}
      />

      <div className="container relative z-10">
        {/* Section header */}
        <div
          className="mb-16"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1)",
          }}
        >
          <div
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase mb-4"
            style={{
              background: "oklch(0.65 0.20 230 / 0.1)",
              border: "1px solid oklch(0.65 0.20 230 / 0.25)",
              color: "oklch(0.65 0.20 230)",
            }}
          >
            How It Works
          </div>
          <h2
            className="font-bold"
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2rem, 4vw, 3rem)",
              color: "oklch(0.92 0.04 215)",
            }}
          >
            Thermoelectric Magic
          </h2>
          <p className="mt-3 max-w-xl" style={{ color: "oklch(0.60 0.05 225)" }}>
            The Peltier principle converts electricity directly into cold — no moving parts, no noise, pure physics.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-start">
          {/* Left: Step list */}
          <div className="flex flex-col gap-4">
            {steps.map((step, i) => (
              <button
                key={step.id}
                onClick={() => setActiveStep(i)}
                className="text-left rounded-2xl p-5 transition-all duration-300"
                style={{
                  background:
                    activeStep === i
                      ? "oklch(0.13 0.04 240)"
                      : "oklch(0.11 0.035 242 / 0.5)",
                  border: `1px solid ${activeStep === i ? step.color + " / 0.4)" : "oklch(1 0 0 / 6%)"}`,
                  borderColor: activeStep === i ? step.color.replace(")", " / 0.4)") : "oklch(1 0 0 / 6%)",
                  transform: activeStep === i ? "translateX(8px)" : "translateX(0)",
                  opacity: visible ? 1 : 0,
                  transitionDelay: `${i * 0.1 + 0.3}s`,
                }}
              >
                <div className="flex items-start gap-4">
                  <div
                    className="flex-shrink-0 w-10 h-10 rounded-xl flex items-center justify-center text-lg"
                    style={{
                      background: activeStep === i ? step.color + " / 0.15)" : "oklch(1 0 0 / 4%)",
                      backgroundColor: activeStep === i
                        ? step.color.includes("oklch") ? step.color.replace(")", " / 0.15)") : step.color
                        : "oklch(1 0 0 / 4%)",
                    }}
                  >
                    {step.icon}
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between gap-2">
                      <span
                        className="text-xs font-mono uppercase tracking-wider"
                        style={{ color: "oklch(0.50 0.05 225)" }}
                      >
                        Adım {step.id} — {step.subtitle}
                      </span>
                      <span
                        className="text-xs font-mono px-2 py-0.5 rounded"
                        style={{
                          background: "oklch(0.65 0.20 230 / 0.1)",
                          color: "oklch(0.65 0.20 230)",
                        }}
                      >
                        {step.detail}
                      </span>
                    </div>
                    <h3
                      className="font-semibold mt-1"
                      style={{
                        fontFamily: "'Space Grotesk', sans-serif",
                        color: activeStep === i ? "oklch(0.92 0.04 215)" : "oklch(0.70 0.04 220)",
                      }}
                    >
                      {step.title}
                    </h3>
                    {activeStep === i && (
                      <p
                        className="text-sm mt-2 leading-relaxed"
                        style={{
                          color: "oklch(0.60 0.05 225)",
                          animation: "fade-up 0.3s ease-out forwards",
                        }}
                      >
                        {step.description}
                      </p>
                    )}
                  </div>
                </div>
              </button>
            ))}
          </div>

          {/* Right: Visual diagram */}
          <div
            className="relative flex items-center justify-center"
            style={{
              opacity: visible ? 1 : 0,
              transform: visible ? "translateX(0)" : "translateX(40px)",
              transition: "all 0.8s cubic-bezier(0.23, 1, 0.32, 1) 0.4s",
            }}
          >
            <div
              className="relative w-full max-w-sm rounded-3xl p-8"
              style={{
                background: "oklch(0.13 0.04 240)",
                border: "1px solid oklch(1 0 0 / 8%)",
              }}
            >
              {/* Peltier diagram */}
              <div className="flex flex-col items-center gap-4">
                {/* Hot side */}
                <div
                  className="w-full rounded-xl py-4 text-center transition-all duration-500"
                  style={{
                    background: activeStep === 0
                      ? "oklch(0.75 0.15 65 / 0.3)"
                      : "oklch(0.75 0.15 65 / 0.12)",
                    border: "1px solid oklch(0.75 0.15 65 / 0.3)",
                  }}
                >
                  <div className="text-2xl mb-1">🔥</div>
                  <div className="text-xs font-mono" style={{ color: "oklch(0.75 0.15 65)" }}>
                    SICAK YÜZ
                  </div>
                  <div className="text-lg font-bold font-mono" style={{ color: "oklch(0.75 0.15 65)" }}>
                    ~45°C
                  </div>
                </div>

                {/* Peltier module */}
                <div
                  className="w-full rounded-xl py-5 text-center relative overflow-hidden transition-all duration-500"
                  style={{
                    background: activeStep === 1
                      ? "oklch(0.65 0.20 230 / 0.25)"
                      : "oklch(0.65 0.20 230 / 0.1)",
                    border: `1px solid oklch(0.65 0.20 230 / ${activeStep === 1 ? "0.6" : "0.25"})`,
                  }}
                >
                  <div className="text-xs font-mono uppercase tracking-wider mb-1" style={{ color: "oklch(0.55 0.05 225)" }}>
                    Peltier Modülü
                  </div>
                  <div className="text-base font-bold" style={{ color: "oklch(0.72 0.12 220)" }}>
                    TEC1-12706
                  </div>
                  <div className="text-xs font-mono mt-1" style={{ color: "oklch(0.55 0.05 225)" }}>
                    Termoelektrik Dönüşüm
                  </div>
                  {activeStep === 1 && (
                    <div
                      className="absolute inset-0 pointer-events-none"
                      style={{
                        background: "linear-gradient(135deg, oklch(0.75 0.15 65 / 0.1) 0%, oklch(0.65 0.20 230 / 0.1) 100%)",
                        animation: "heat-cold-flow 1s ease-in-out infinite",
                      }}
                    />
                  )}
                </div>

                {/* Aluminum block */}
                <div
                  className="w-full rounded-xl py-4 text-center transition-all duration-500"
                  style={{
                    background: activeStep === 2
                      ? "oklch(0.72 0.12 220 / 0.25)"
                      : "oklch(0.72 0.12 220 / 0.08)",
                    border: "1px solid oklch(0.72 0.12 220 / 0.3)",
                  }}
                >
                  <div className="text-2xl mb-1">🧊</div>
                  <div className="text-xs font-mono" style={{ color: "oklch(0.72 0.12 220)" }}>
                    ALÜMİNYUM BLOK
                  </div>
                  <div className="text-lg font-bold font-mono" style={{ color: "oklch(0.72 0.12 220)" }}>
                    60×60mm
                  </div>
                </div>

                {/* Cold side / Fan */}
                <div
                  className="w-full rounded-xl py-4 text-center transition-all duration-500"
                  style={{
                    background: activeStep === 3
                      ? "oklch(0.65 0.20 230 / 0.2)"
                      : "oklch(0.65 0.20 230 / 0.06)",
                    border: "1px solid oklch(0.65 0.20 230 / 0.25)",
                  }}
                >
                  <div className="text-2xl mb-1">❄️</div>
                  <div className="text-xs font-mono" style={{ color: "oklch(0.65 0.20 230)" }}>
                    SOĞUK HAVA ÇIKIŞI
                  </div>
                  <div className="text-lg font-bold font-mono" style={{ color: "oklch(0.65 0.20 230)" }}>
                    ~18°C
                  </div>
                </div>
              </div>

              {/* Progress indicator */}
              <div className="flex gap-2 justify-center mt-6">
                {steps.map((_, i) => (
                  <button
                    key={i}
                    onClick={() => setActiveStep(i)}
                    className="rounded-full transition-all duration-300"
                    style={{
                      width: activeStep === i ? "24px" : "8px",
                      height: "8px",
                      background: activeStep === i
                        ? "oklch(0.65 0.20 230)"
                        : "oklch(0.65 0.20 230 / 0.3)",
                    }}
                  />
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
