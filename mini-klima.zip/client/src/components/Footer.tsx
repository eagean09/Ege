// Soğuk Nefes Teması — Footer
const logoUrl = "https://3000-ir6303a50hvqgzb51ydh4-4ee4a2b5.sg1.manus.computer/manus-storage/logo_icon_bded498f.png";

export default function Footer() {
  return (
    <footer
      className="relative py-12 overflow-hidden"
      style={{ background: "oklch(0.08 0.025 248)" }}
    >
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          backgroundImage: `
            linear-gradient(oklch(0.65 0.20 230 / 0.03) 1px, transparent 1px),
            linear-gradient(90deg, oklch(0.65 0.20 230 / 0.03) 1px, transparent 1px)
          `,
          backgroundSize: "60px 60px",
        }}
      />

      <div className="container relative z-10">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          {/* Logo + name */}
          <div className="flex items-center gap-3">
            <img src={logoUrl} alt="Mini Cool" className="w-8 h-8 opacity-80" />
            <div>
              <div
                className="font-bold"
                style={{ fontFamily: "'Space Grotesk', sans-serif", color: "oklch(0.92 0.04 215)" }}
              >
                Mini<span style={{ color: "oklch(0.65 0.20 230)" }}>Cool</span>
              </div>
              <div className="text-xs" style={{ color: "oklch(0.45 0.05 225)" }}>
                Peltier Thermoelectric Cooling Project
              </div>
            </div>
          </div>

          {/* Links */}
          <div className="flex items-center gap-6">
            {[
              { label: "Project", href: "#proje" },
              { label: "How It Works", href: "#calisma" },
              { label: "Components", href: "#bilesenleri" },
              { label: "Specs", href: "#teknik" },
            ].map((link) => (
              <a
                key={link.href}
                href={link.href}
                className="text-sm transition-colors duration-200"
                style={{ color: "oklch(0.50 0.05 225)" }}
                onMouseEnter={(e) => (e.currentTarget.style.color = "oklch(0.72 0.12 220)")}
                onMouseLeave={(e) => (e.currentTarget.style.color = "oklch(0.50 0.05 225)")}
              >
                {link.label}
              </a>
            ))}
          </div>

          {/* CAD link */}
          <a
            href="https://cad.onshape.com/documents/21fe0276ffc8c6ed3b8018b1/w/d76675b1995a050e7ea5c5d8/e/3160da51f33fcb1a54985a75"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm font-mono transition-colors duration-200"
            style={{ color: "oklch(0.55 0.10 225)" }}
            onMouseEnter={(e) => (e.currentTarget.style.color = "oklch(0.72 0.12 220)")}
            onMouseLeave={(e) => (e.currentTarget.style.color = "oklch(0.55 0.10 225)")}
          >
            OnShape CAD ↗
          </a>
        </div>

        <div
          className="mt-8 pt-6 text-center text-xs"
          style={{
            borderTop: "1px solid oklch(1 0 0 / 6%)",
            color: "oklch(0.40 0.04 230)",
          }}
        >
          Mini Cool — Thermoelectric Cooling Project · Designed with OnShape
        </div>
      </div>
    </footer>
  );
}
