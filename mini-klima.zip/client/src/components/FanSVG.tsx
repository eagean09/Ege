// Soğuk Nefes Teması — Dönen fan SVG animasyonu
interface FanSVGProps {
  size?: number;
  speed?: "fast" | "slow" | "medium";
  color?: string;
  glowColor?: string;
}

export default function FanSVG({
  size = 120,
  speed = "medium",
  color = "oklch(0.72 0.12 220)",
  glowColor = "oklch(0.65 0.20 230)",
}: FanSVGProps) {
  const duration = speed === "fast" ? "1.5s" : speed === "slow" ? "6s" : "3s";

  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 120 120"
      style={{
        filter: `drop-shadow(0 0 8px ${glowColor})`,
      }}
    >
      {/* Hub */}
      <circle cx="60" cy="60" r="8" fill={color} opacity="0.9" />
      <circle cx="60" cy="60" r="4" fill="oklch(0.09 0.03 245)" />

      {/* Spinning blades group */}
      <g
        style={{
          transformOrigin: "60px 60px",
          animation: `fan-spin ${duration} linear infinite`,
        }}
      >
        {/* 7 blades */}
        {Array.from({ length: 7 }).map((_, i) => {
          const angle = (i * 360) / 7;
          return (
            <g
              key={i}
              style={{
                transformOrigin: "60px 60px",
                transform: `rotate(${angle}deg)`,
              }}
            >
              <ellipse
                cx="60"
                cy="35"
                rx="7"
                ry="20"
                fill={color}
                opacity="0.85"
                style={{ transformOrigin: "60px 60px", transform: "rotate(-15deg)" }}
              />
            </g>
          );
        })}
      </g>

      {/* Outer ring */}
      <circle
        cx="60"
        cy="60"
        r="55"
        fill="none"
        stroke={color}
        strokeWidth="2"
        opacity="0.3"
      />
      <circle
        cx="60"
        cy="60"
        r="50"
        fill="none"
        stroke={color}
        strokeWidth="1"
        opacity="0.15"
      />
    </svg>
  );
}

