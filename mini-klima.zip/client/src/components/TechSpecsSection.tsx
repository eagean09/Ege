// Soğuk Nefes Teması — Teknik Özellikler: animasyonlu sayaçlar ve progress bar'lar
import { useEffect, useRef, useState } from "react";

function AnimatedNumber({ target, suffix = "", duration = 1500 }: { target: number; suffix?: string; duration?: number }) {
  const [value, setValue] = useState(0);
  const [started, setStarted] = useState(false);
  const ref = useRef<HTMLSpanElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting && !started) setStarted(true); },
      { threshold: 0.5 }
    );
    if (ref.current) observer.observe(ref.current);
    return () => observer.disconnect();
  }, [started]);

  useEffect(() => {
    if (!started) return;
    const start = Date.now();
    const tick = () => {
      const elapsed = Date.now() - start;
      const progress = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - progress, 3);
      setValue(Math.round(eased * target));
      if (progress < 1) requestAnimationFrame(tick);
    };
    requestAnimationFrame(tick);
  }, [started, target, duration]);

  return <span ref={ref}>{value}{suffix}</span>;
}

function ProgressBar({ label, value, max, color, unit, visible }: {
  label: string; value: number; max: number; color: string; unit: string; visible: boolean;
}) {
  const pct = (value / max) * 100;
  return (
    <div className="flex flex-col gap-2">
      <div className="flex justify-between items-center">
        <span className="text-sm font-medium" style={{ color: "oklch(0.75 0.04 220)" }}>{label}</span>
        <span className="text-sm font-mono font-bold" style={{ color }}>
          {value}{unit}
        </span>
      </div>
      <div
        className="h-2 rounded-full overflow-hidden"
        style={{ background: "oklch(1 0 0 / 6%)" }}
      >
        <div
          className="h-full rounded-full transition-all duration-1000"
          style={{
            width: visible ? `${pct}%` : "0%",
            background: `linear-gradient(90deg, ${color}, ${color.replace(")", " / 0.6)")})`,
            boxShadow: `0 0 8px ${color.replace(")", " / 0.4)")}`,
            transitionTimingFunction: "cubic-bezier(0.23, 1, 0.32, 1)",
          }}
        />
      </div>
    </div>
  );
}

export default function TechSpecsSection() {
  const [visible, setVisible] = useState(false);
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) setVisible(true); },
      { threshold: 0.15 }
    );
    if (sectionRef.current) observer.observe(sectionRef.current);
    return () => observer.disconnect();
  }, []);

  const stats = [
    { label: "Güç Tüketimi", value: 60, suffix: "W", color: "oklch(0.75 0.15 65)" },
    { label: "Fan Boyutu", value: 60, suffix: "mm", color: "oklch(0.72 0.12 220)" },
    { label: "Çalışma Voltajı", value: 24, suffix: "V", color: "oklch(0.65 0.20 230)" },
    { label: "Bileşen Sayısı", value: 7, suffix: "", color: "oklch(0.72 0.12 220)" },
  ];

  const bars = [
    { label: "Soğutma Kapasitesi", value: 68, max: 100, color: "oklch(0.65 0.20 230)", unit: "°C ΔT" },
    { label: "Termal İletkenlik", value: 167, max: 200, color: "oklch(0.72 0.12 220)", unit: " W/m·K" },
    { label: "Fan Hava Debisi", value: 85, max: 100, color: "oklch(0.72 0.12 220)", unit: "%" },
    { label: "Kompaktlık Skoru", value: 92, max: 100, color: "oklch(0.75 0.15 65)", unit: "%" },
  ];

  const tableSpecs = [
    { param: "Fan Modeli", value: "24V 60×60×25mm Aksiyel Fan" },
    { param: "Peltier Modülü", value: "TEC1-12706 (40×40mm)" },
    { param: "Soğutma Bloğu", value: "Alüminyum 6061, 60×60mm" },
    { param: "Dış Kasa", value: "3D Baskı (PLA/PETG)" },
    { param: "Peltier Tutucu", value: "3D Baskı Montaj Elemanı" },
    { param: "Bağlantı Tipi", value: "5× Fastened Mate" },
    { param: "Güç Kaynağı", value: "24V DC" },
    { param: "Tasarım Aracı", value: "OnShape CAD" },
  ];

  return (
    <section
      id="teknik"
      ref={sectionRef}
      className="relative py-24 overflow-hidden"
      style={{ background: "oklch(0.09 0.03 245)" }}
    >
      <div className="container relative z-10">
        {/* Header */}
        <div
          className="mb-14"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateY(0)" : "translateY(30px)",
            transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1)",
          }}
        >
          <div
            className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full text-xs font-semibold tracking-wider uppercase mb-4"
            style={{
              background: "oklch(0.65 0.20 230 / 0.1)",
              border: "1px solid oklch(0.65 0.20 230 / 0.25)",
              color: "oklch(0.65 0.20 230)",
            }}
          >
            Technical Data
          </div>
          <h2
            className="font-bold"
            style={{
              fontFamily: "'Space Grotesk', sans-serif",
              fontSize: "clamp(2rem, 4vw, 3rem)",
              color: "oklch(0.92 0.04 215)",
            }}
          >
            Cooling by Numbers
          </h2>
        </div>

        <div className="grid lg:grid-cols-2 gap-12">
          {/* Left: Stats + Progress bars */}
          <div className="flex flex-col gap-8">
            {/* Animated stats */}
            <div className="grid grid-cols-2 gap-4">
              {stats.map((stat, i) => (
                <div
                  key={stat.label}
                  className="rounded-2xl p-5 flex flex-col gap-1"
                  style={{
                    background: "oklch(0.13 0.04 240)",
                    border: "1px solid oklch(1 0 0 / 8%)",
                    opacity: visible ? 1 : 0,
                    transform: visible ? "translateY(0)" : "translateY(20px)",
                    transition: `all 0.6s cubic-bezier(0.23, 1, 0.32, 1) ${i * 0.1 + 0.2}s`,
                  }}
                >
                  <span className="text-3xl font-bold font-mono" style={{ color: stat.color }}>
                    {visible ? <AnimatedNumber target={stat.value} suffix={stat.suffix} /> : `0${stat.suffix}`}
                  </span>
                  <span className="text-xs" style={{ color: "oklch(0.55 0.05 225)" }}>
                    {stat.label}
                  </span>
                </div>
              ))}
            </div>

            {/* Progress bars */}
            <div
              className="rounded-2xl p-6 flex flex-col gap-5"
              style={{
                background: "oklch(0.13 0.04 240)",
                border: "1px solid oklch(1 0 0 / 8%)",
                opacity: visible ? 1 : 0,
                transform: visible ? "translateY(0)" : "translateY(20px)",
                transition: "all 0.7s cubic-bezier(0.23, 1, 0.32, 1) 0.5s",
              }}
            >
              <h3
                className="font-semibold text-sm"
                style={{ fontFamily: "'Space Grotesk', sans-serif", color: "oklch(0.75 0.04 220)" }}
              >
                Performans Göstergeleri
              </h3>
              {bars.map((bar) => (
                <ProgressBar key={bar.label} {...bar} visible={visible} />
              ))}
            </div>
          </div>

          {/* Right: Specs table */}
          <div
            className="rounded-2xl overflow-hidden"
            style={{
              background: "oklch(0.13 0.04 240)",
              border: "1px solid oklch(1 0 0 / 8%)",
              opacity: visible ? 1 : 0,
              transform: visible ? "translateX(0)" : "translateX(40px)",
              transition: "all 0.8s cubic-bezier(0.23, 1, 0.32, 1) 0.3s",
            }}
          >
            <div
              className="px-6 py-4 border-b"
              style={{ borderColor: "oklch(1 0 0 / 8%)" }}
            >
              <h3
                className="font-semibold"
                style={{ fontFamily: "'Space Grotesk', sans-serif", color: "oklch(0.92 0.04 215)" }}
              >
                Malzeme Listesi (BOM)
              </h3>
            </div>
            <div className="divide-y" style={{ borderColor: "oklch(1 0 0 / 5%)" }}>
              {tableSpecs.map((spec, i) => (
                <div
                  key={spec.param}
                  className="flex items-center justify-between px-6 py-3.5 transition-colors duration-150"
                  style={{
                    opacity: visible ? 1 : 0,
                    transitionDelay: `${i * 0.05 + 0.5}s`,
                  }}
                  onMouseEnter={(e) => { e.currentTarget.style.background = "oklch(0.65 0.20 230 / 0.05)"; }}
                  onMouseLeave={(e) => { e.currentTarget.style.background = "transparent"; }}
                >
                  <span className="text-sm" style={{ color: "oklch(0.55 0.05 225)" }}>
                    {spec.param}
                  </span>
                  <span className="text-sm font-medium font-mono text-right" style={{ color: "oklch(0.80 0.06 220)" }}>
                    {spec.value}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
