// Soğuk Nefes Teması — Her bölüm arası soğuk hava akışı motifi
interface ColdBreathDividerProps {
  reverse?: boolean;
}

export default function ColdBreathDivider({ reverse = false }: ColdBreathDividerProps) {
  return (
    <div
      className="relative w-full overflow-hidden pointer-events-none"
      style={{ height: "80px", marginTop: "-1px" }}
    >
      {/* Flowing cold air lines */}
      <svg
        viewBox="0 0 1280 80"
        preserveAspectRatio="none"
        className="absolute inset-0 w-full h-full"
        style={{ transform: reverse ? "scaleY(-1)" : "none" }}
      >
        {/* Wavy cold air streams */}
        {[0, 1, 2, 3, 4].map((i) => (
          <path
            key={i}
            d={`M ${i * 260 - 50} 80 Q ${i * 260 + 80} ${20 + i * 8} ${i * 260 + 200} 80 T ${i * 260 + 450} 80`}
            fill="none"
            stroke={`oklch(0.65 0.20 230 / ${0.04 + i * 0.01})`}
            strokeWidth="1"
          />
        ))}
        {/* Particle dots */}
        {[100, 300, 500, 700, 900, 1100].map((x, i) => (
          <circle
            key={x}
            cx={x}
            cy={30 + (i % 3) * 15}
            r="1.5"
            fill={`oklch(0.72 0.12 220 / ${0.2 + (i % 3) * 0.1})`}
          />
        ))}
      </svg>
      {/* Gradient fade */}
      <div
        className="absolute inset-0"
        style={{
          background: "linear-gradient(to bottom, transparent 0%, oklch(0.09 0.03 245 / 0.3) 100%)",
        }}
      />
    </div>
  );
}
